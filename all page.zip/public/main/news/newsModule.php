<?php
    echo '
        <div class="post">
            <h1>Under Maintenance</h1>
            <p>Our lovely news section is under development. Be patient :3</p>
        </div>';
?>