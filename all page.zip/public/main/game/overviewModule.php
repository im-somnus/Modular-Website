<div class="donationCenter">
            <h2 class='h2Titles'> Overview</h2>
    <div class="windowShop">
    <p>This is a clicking game! Click the cubes that fall in order to obtain points</p>
    <p>These points can be traded in the <a href="index.php?shop">shop</a> for stuff, including skins and more!</p>
    
    <img src="assets/images/others/overview.png" width="100%;">
    </div>
</div>
