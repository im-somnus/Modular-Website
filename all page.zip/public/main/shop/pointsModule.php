<div class="donationCenter">
            <h2 class='h2Titles'> Point System</h2>
    <div class="windowShop">

        <h3>What are Trade Points?</h3>
        - Trade Points are the main forum currency, they are non-refundable.<br>
        <h3>How do I obtain Trade Points?</h3>
        - Donations: you can donate to the site. Trade Points are automatically added to your account after you do so.<br>
        - Contests: official and unofficial forum contests may reward the winners with Trade Points<br>
        <h3>What am I allowed to do with Trade Points?</h3>
        - Items: trade it for in-game stuff from the shop center.<br>
        <h3> What should I not do with Trade Points?</h3>
        - Selling Trade Points for real money is strictly prohibited and will lead to account suspension and partial or complete loss of your Trade Points.<br>
        - The sale of you Forum accounts is prohibited.<br>   
        <br>
    </div>
</div>
