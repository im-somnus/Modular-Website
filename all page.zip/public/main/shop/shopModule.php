<?php
    echo '
        <div class="post">
        <div class="windowMain">
            <h1>Under Maintenance</h1>
            <p>Our lovely shop is under development. Be patient :3</p>
        </div></div>';
?>