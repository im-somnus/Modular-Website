<?php
    echo '
        <div class="post">
            <h1>Under Maintenance</h1>
            <p>Our best writters are currently working on the first Code of Conduct for our forum, please be patient they need to rest at least 13h a day to stay fresh :3</p>
        </div>';

        // TODO delete, put a link to our forum instead of this file
        
?>