<?php
       echo '<div class="row">
       <div id="logoPicture">
           <a href="./index.php"><img style="width: 100%;" src="assets/images/others/logo.png"/></a>
       </div></div>';
   
?>